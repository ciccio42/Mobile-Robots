#/bin/bash
echo "source ../../devel/setup.bash"
source ../../devel/setup.bash

echo "python3 run_test.py"
python3 run_test.py

