#! /bin/bash 
bash $HOME/turtlebot3_network/server_run.bash & 
bash $HOME/turtlebot3_network/host_run.bash &
